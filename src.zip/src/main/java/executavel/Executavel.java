package executavel;

import model.view.Login;

public class Executavel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Login login = new Login();
		login.apresentarMenuLogin();
	
	}

}
